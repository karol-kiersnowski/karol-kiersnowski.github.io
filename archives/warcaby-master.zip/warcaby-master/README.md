Warcaby
=======

Technologie
-----------
* Język: Java
* Biblioteki: AWT, Swing
* IDE: NetBeans

Język
-----
* Interfejs użytkownika: polski
* Kod źródłowy: polski

Autor
-----
kargol92

Licencja
--------
GNU General Public License
