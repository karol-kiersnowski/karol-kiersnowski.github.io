#!/bin/sh
java -jar "dist/Warcaby.jar"
