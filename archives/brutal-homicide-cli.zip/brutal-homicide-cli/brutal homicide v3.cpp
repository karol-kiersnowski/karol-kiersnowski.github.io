/////////////////////////////////////////////////////
// BRUTAL HOMICIDE v. 2.0                          // 
//                                                 //
// IF THIS DOESN'T WORK, TURN OFF THE CAPS LOCK :D //
/////////////////////////////////////////////////////
/*
 ______   ______ _     _ _______ _______       
 |_____] |_____/ |     |    |    |_____| |     
 |_____] |    \_ |_____|    |    |     | |_____
                                               
 _     _  _____  _______ _____ _______ _____ ______  _______
 |_____| |     | |  |  |   |   |         |   |     \ |______
 |     | |_____| |  |  | __|__ |_____  __|__ |_____/ |______

*/

#include <iostream>
#include <conio.h>
#include <windows.h>
#define MAX_X 39
#define MAX_Y 22
using namespace std;

////////////////////////////////////////////////////////////////////////////////
//---------------------------DECLARATIONS OF FUNCTIONS------------------------//
////////////////////////////////////////////////////////////////////////////////

void game ();
void settings ();
void about ();
void drawMap ();
void stand ();
void up ();
void down ();
void left ();
void right ();
void grenade ();
void setColor ();

////////////////////////////////////////////////////////////////////////////////
//-------------------------------GLOBAL VARIABLES-----------------------------//
////////////////////////////////////////////////////////////////////////////////

struct charackter
{
       short x;
       short y;
       char energy;
       char grenades;
       short ammo;
       short money;
       
};

// YOUR LOCATION ON THE MAP
//int x = 2;
//int y = 2;

// SETTINGS
char border = '#';
char base = '%';
char wall = '*';
int color = 0;

// MAP
unsigned char map [MAX_Y][MAX_X] =
{
         { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 },
         { 0 ,120,120,120,120,120,120,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110},
         { 0 ,120,100, 0 , 0 , 0 ,140, 0 , 0 , 0 , 0 ,130,130,130,130,130,130, 0 ,130, 0 , 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,120,120,120, 1 , 2 ,120,130,130,130, 0 , 0 , 0 , 0 , 0 , 0 ,130, 0 ,130, 0 ,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,120, 3 ,120, 2 , 2 ,120,130, 0 , 0 , 0 ,130,130,130,130,130,130, 0 , 0 , 0 ,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,120, 0 , 0 , 0 , 0 ,130, 0 , 0 ,130, 0 ,130, 0 , 0 , 0 , 0 ,130, 0 ,130, 0 , 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,120,150,120,120,150,120, 0 ,130, 0 , 0 ,130, 0 , 0 ,130, 0 ,130, 0 ,130, 0 ,130,130,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 , 0 , 0 , 0 , 0 , 0 , 0 ,130, 0 , 0 ,130, 0 ,130, 0 , 0 , 0 ,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110,130,130,130,130, 4 ,130, 0 , 0 ,130, 0 ,130, 0 ,130,130,130, 0 , 0 , 0 ,130,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 3 ,130, 0 ,130, 0 ,130, 0 , 0 ,130, 0 ,130, 0 , 0 , 0 ,130, 0 ,130,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 ,130, 0 , 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 ,130,130,130, 0 , 0 ,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 ,130, 0 ,130,130,130,130,130,130,130,130,130,130, 0 , 0 , 0 ,130,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 , 0 , 0 , 0 ,130, 0 , 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 ,130,130,130, 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 ,130,130, 0 ,130, 0 ,130,130,130,130,130,130,130,130,130,130,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 , 0 ,130, 0 ,130, 0 , 0 , 0 ,130, 0 ,130, 0 ,130, 0 , 0 , 0 , 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110,130, 0 ,130, 0 ,130, 0 ,130, 0 ,130, 0 ,130, 0 ,130,130, 0 ,130,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110,130, 0 , 0 , 0 , 0 , 0 ,130, 0 ,130, 0 ,130, 0 ,130, 0 , 0 ,130,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110,130,130,130,130,130,130,130, 0 , 0 , 0 , 0 , 0 ,130, 0 ,130,130,130, 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,130, 0 ,130, 0 ,130, 0 , 0 ,130,130, 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110,130, 0 ,130,130,130,130,130,130, 0 , 0 ,130, 0 ,130,130, 0 ,130,130,130, 0 ,130,130, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,130,130,130, 0 , 0 , 0 , 0 , 0 , 0 ,130, 0 , 0 , 0 , 0 , 0 , 0 , 0,  0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,110},
         { 0 ,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110,110}
};

////////////////////////////////////////////////////////////////////////////////
//-------------------------------MAIN FUNCTION--------------------------------//
////////////////////////////////////////////////////////////////////////////////

int main ()
{
    ios_base::sync_with_stdio(0);
    bool mainRunning = true;
    while (mainRunning)
    {
           cout << endl << endl << endl << endl << endl << endl << endl; cout.width (30);
           cout << " ______   ______ _     _ _______ _______       " << endl; cout.width (30);
           cout << " |_____] |_____/ |     |    |    |_____| |     " << endl; cout.width (30);
           cout << " |_____] |    \\_ |_____|    |    |     | |_____" << endl; cout.width (30);
           cout << "                                               " << endl; cout.width (30);
           cout << " _     _  _____  _______ _____ _______ _____ ______  _______" << endl; cout.width (30);
           cout << " |_____| |     | |  |  |   |   |         |   |     \\ |______" << endl; cout.width (30);
           cout << " |     | |_____| |  |  | __|__ |_____  __|__ |_____/ |______" << endl; cout.width (30);
           cout << "                                                            " << endl; cout.width (60);
           cout << "the_black_coder" << endl << endl << endl << endl << endl;
           cout << " 1. Start" << endl;
           cout << " 2. Options" << endl;
           cout << " 3. About" << endl;
           cout << " 4. Exit" << endl;
           
           // CHOOSING
           cout << endl << " ";
           char key = getch ();
           if (key == '1') {system ("cls"); game (); }
           if (key == '2') {system ("cls"); settings (); }
           if (key == '3') {system ("cls"); about (); }
           if (key == '4') mainRunning = false;
           if (key == 27) mainRunning = false;
           system ("cls");
    }
    return 0;
}

////////////////////////////////////////////////////////////////////////////////
//-------------------------------GAME FUNCTION--------------------------------//
////////////////////////////////////////////////////////////////////////////////

void game ()
{
    charackter man; 
    man.x = 2;
    man.y = 2;
    
    bool gameRunning = true;
    
    // STUFF
    bool energy1 = false;
    bool energy2 = false;
    bool grenade1 = false;
    bool grenade2 = false;
    bool grenade3 = false;
    int ammo1 = 0;
    bool mine1 = false;
    int money1 = 0;

    // MAIN LOOP
    while (gameRunning)
    {
          cout << endl;
          drawMap ();
          
          // DISCOVERING STUFF
          if (man.x==2 && man.y==4) {map [4][2] = 0; energy1 = true;}
          if (man.x==2 && man.y==9) {map [9][2] = 0; energy2 = true;}
          if (man.x==4 && man.y==3) {map [3][4] = 0; ammo1 = 50;}
          if (man.x==5 && man.y==3) {map [3][5] = 0; grenade1 = true;}
          if (man.x==5 && man.y==4) {map [4][5] = 0; grenade2 = true;}
          if (man.x==4 && man.y==4) {map [4][4] = 0; grenade3 = true;}
          if (man.x==6 && man.y==8) {map [8][6] = 0; money1 = 50;}
          // CALCULATING STUFF
          int pickGrenades = grenade1 + grenade2 + grenade3;
          int throwGrenades;
          int allGrenades = pickGrenades - throwGrenades;
          int energy = 75 + 25 * energy1 + 25 * energy2 - 25 * mine1;
          if (energy > 100) energy = 100;
          int ammo = ammo1;
          int mines = mine1;
          int money = money1;
          // DISPLAYING STUFF
          cout << endl;
          cout << " Grenades: " << allGrenades << endl;
          cout << " Weapon: " << "M4" << endl;
          cout << " Ammo: " << ammo << endl;
          cout << " Energy: " << energy << "%" << endl;
          cout << " Money: " << money << "$" << endl;
          
          
          // MOVING AND EVENTS
          char key = getch ();
          _sleep (75);
          if (key == 'w' && map [man.y-1][man.x] != 110 && map[man.y-1][man.x] != 120 && map[man.y-1][man.x] != 130) up (); else stand ();
          if (key == 's' && map [man.y+1][man.x] != 110 && map[man.y+1][man.x] != 120 && map[man.y+1][man.x] != 130) down (); else stand ();
          if (key == 'a' && map [man.y][man.x-1] != 110 && map[man.y][man.x-1] != 120 && map[man.y][man.x-1] != 130) left (); else stand ();
          if (key == 'd' && map [man.y][man.x+1] != 110 && map[man.y][man.x+1] != 120 && map[man.y][man.x+1] != 130) right (); else stand ();
          if (key==32 && allGrenades > 0) {grenade (); throwGrenades = throwGrenades + 1;}
          if (key==27) gameRunning = false;
          
          // GATES
          if (man.x==5 && man.y==2 || man.x==7 && man.y==2) map [2][6] = 0;
                   else if (man.x==6 && man.y==2) map [2][6] = 100;
                   else map [2][6] = 140;
          if (man.x==2 && man.y==5 || man.x==2 && man.y==7) map [6][2] = 0;
                   else if (man.x==2 && man.y==6) map [6][2] = 100;
                   else map [6][2] = 150;
          if (man.x==5 && man.y==5 || man.x==5 && man.y==7) map [6][5] = 0;
                   else if (man.x==5 && man.y==6) map [6][5] = 100;
                   else map [6][5] = 150;
          system ("cls");
    }
}

////////////////////////////////////////////////////////////////////////////////
//-----------------------------SETTINGS FUNCTION------------------------------//
////////////////////////////////////////////////////////////////////////////////

void settings ()
{
     bool settingsRunning = true;
     while (settingsRunning)
     {
           bool colorsRunning = false;
           cout << endl << endl << endl;
           cout.width (43);
           cout << "Options" << endl << endl << endl << endl << endl;
           cout << " o     Grenade" << endl << endl;
           cout << " ^     Ammunation" << endl << endl;
           cout << " +     First Aid (25% of energy)" << endl << endl;
           cout << " $     Money" << endl << endl;
           cout << " ?     Various effects" << endl << endl;
           cout << " " << border << "     Border walls                                   | Press 1. to change" << endl << endl;
           cout << " " << base << "     Base walls                                     | Press 2. to change " << endl << endl;
           cout << " " << wall << "     Walls                                          | Press 3. to change" << endl << endl << endl << endl;
           cout << " Color                                                | Press 4. to change" << endl << endl;
           cout << endl << " ";
           char key = getch ();
           if (key == '1') {cout << "Write the sign for border walls: "; cin >> border;}
           if (key == '2') {cout << "Write the sign for base walls: "; cin >> base;}
           if (key == '3') {cout << "Write the sign for walls: "; cin >> wall;}
           if (key == '4') {cout << "Use the 'w' and 's' keys to change color" << endl; colorsRunning = true;}
           while (colorsRunning)
           {
                 char key = getch ();
                 if (key == 'w' && color <= 255) {color++; setColor (); cout << "\r Kolor = " << color << endl;}
                 else if (key == 's' && color >= 0) {color--; setColor (); cout << "\r Kolor = " << color << endl;}
                 if (key == 27) colorsRunning = false;
                 //system ("cls");
           }
           if (key == 27) settingsRunning = false;
           system ("cls");
     }
}

void about ()
{
    bool aboutRunning = true;
    while (aboutRunning)
    {
          cout << endl << endl << endl;
          cout.width (42);
          cout << "About" << endl << endl << endl << endl << endl << " ";
          cout << "Brutal Homicide v. 2.1, last modification - 04/15/12 10:03 p.m." << endl << endl << " ";
          cout << "Version 2.0 - added the continuous freshing  of the map" << endl << endl << " ";
          cout << "Version 2.1 - changed arguments of functions to global variables," << endl << endl
               << " clearing the source code";
          char key = getch ();
          if (key == 27) aboutRunning = false;
          system ("cls");
    }
}


////////////////////////////////////////////////////////////////////////////////
//----------------------------DEFINITIONS OF FUNCTIONS------------------------//
////////////////////////////////////////////////////////////////////////////////

void drawMap ()
{
     for (int y = 0; y < MAX_Y; y++)
     {
         for (int x = 0; x < MAX_X; x++)
         {
                  if (map [y][x] == 0) cout << ' '; // SPACE
             else if (map [y][x] == 110) cout << border; // INDESTRUCTIBLE WALL - BORDER
             else if (map [y][x] == 120) cout << base; // INDESTRUCTIBLE WALL - BASE
             else if (map [y][x] == 130) cout << wall; // WALL
             else if (map [y][x] == 140) cout << "|"; // GATE 1
             else if (map [y][x] == 150) cout << "-"; // GATE 2, 3
             else if (map [y][x] == 1) cout << "^"; // AMMO
             else if (map [y][x] == 2) cout << "o"; // GRENADE
             else if (map [y][x] == 3) cout << "+"; // ENERGY
             else if (map [y][x] == 4) cout << "$"; // MONEY
             else if (map [y][x] == 100) cout << "@"; // PLAYER
         }
         cout << "\n";
         //cout << endl;
     }
     cout << endl;
}

void stand ()
{
     map [man.y][man.x] = 100;
}

void up ()
{
     map [man.y][man.x] = 0;
     man.y = man.y-1;
     map [man.y][man.x] = 100;
}

void down ()
{
     map [man.y][man.x] = 0;
     man.y = man.y+1;
     map [man.y][man.x] = 100;
}

void left ()
{
     map [man.y][man.x] = 0;
     man.x = man.x-1;
     map [man.y][man.x] = 100;
}

void right ()
{
     map [man.y][man.x] = 0;
     man.x = man.x+1;
     map [man.y][man.x] = 100;
}

void grenade ()
{
     if (map [man.y-1][man.x] != 110 && map [man.y-1][man.x] != 120) {man.y = man.y-1; map [man.y][man.x] = 0; man.y = man.y+1;}
     if (map [man.y+1][man.x] != 110 && map [man.y+1][man.x] != 120) {man.y = man.y+1; map [man.y][man.x] = 0; man.y = man.y-1;}
     if (map [man.x-1][man.x] != 110 && map [man.x-1][man.x] != 120) {man.x = man.x-1; map [man.y][man.x] = 0; man.x = man.x+1;}
     if (map [man.x+1][man.x] != 110 && map [man.x+1][man.x] != 120) {man.x = man.x+1; map [man.y][man.x] = 0; man.x = man.x-1;}
}

void setColor ()
{
     HANDLE hOut;
     hOut = GetStdHandle (STD_OUTPUT_HANDLE);
     SetConsoleTextAttribute (hOut, color);
}
