Brutal Homicide Clone OOP version
=================================
Brutal Homicide is a great game developed on Amiga in the late 90's. I "borrow" the graphics :)

Technologies
------------
* Language: C++
* Library: Allegro 4
* IDE: Code::Blocks

Language
--------
* User interface: English
* Source code: English

Requirements
------------
GNU Linux

Screenshots
-----------
![Brutal Homicide Clone](http://karol-kiersnowski.prv.pl/img/projects/brutal-homicide.png)

Author
------
Karol Kiersnowski

License
-------
[GNU General Public License v3.0](https://github.com/kargol92/football-manager-cli/blob/master/LICENSE)
