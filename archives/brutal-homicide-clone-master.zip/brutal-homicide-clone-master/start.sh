#!/bin/sh
./BH