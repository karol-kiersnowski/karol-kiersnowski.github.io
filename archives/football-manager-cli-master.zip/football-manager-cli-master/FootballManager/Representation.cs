﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FootballManager
{
    class Representation : Team
    {
        //public int id { get; private set; }
        //public string fullName { get; private set; }
        //public string name { get; private set; }
    }
}
