﻿namespace FootballManager
{
    class Training
    {
        //public Training(Club club)
        //{
        //    this.club = club;
        //}

        //Club club;

        //int intensity;
        //int conditioningTraining;
        //int playmakingTraining;
        //int shootingTraining;
        //int intensywnoscTreningu;
        //int treningKondycyjny;
        //int treningRozgrywania;
        //int treningStrzelecki;
        //int treningStalychFragmentowGry;
    }
}
