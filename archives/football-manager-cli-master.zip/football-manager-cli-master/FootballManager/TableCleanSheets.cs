﻿namespace FootballManager
{
    class TableCleanSheets
    {
    }
}
