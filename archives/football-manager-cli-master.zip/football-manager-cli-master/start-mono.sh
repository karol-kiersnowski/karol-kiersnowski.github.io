#!/bin/sh
cd FootballManager/bin/Debug
mono FootballManager.exe