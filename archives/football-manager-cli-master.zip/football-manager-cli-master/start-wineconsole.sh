#!/bin/sh
cd FootballManager/bin/Debug
wineconsole FootballManager.exe