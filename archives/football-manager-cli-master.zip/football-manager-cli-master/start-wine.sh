#!/bin/sh
cd FootballManager/bin/Debug
wine FootballManager.exe