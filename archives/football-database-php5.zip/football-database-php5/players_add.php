<div id="content_title"><h3><?php echo players; ?></h3></div>
<div id="content2">
<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");

	if (isset($_POST['player_first_name']))
	{
        mysql_query( "INSERT INTO players (first_name, last_name, birth_date, club, nationality) VALUES(\"$_POST[player_first_name]\", \"$_POST[player_last_name]\", \"$_POST[player_birth_date]\", \"$_POST[player_club]\", \"$_POST[player_nationality]\") ") or die( mysql_error() );
	}
	mysql_close($link);
?>
	<h2><?php echo add_club ?></h2>
	<form name="form" action="index.php?language=<?php echo $language; ?>&display=players_add" method="POST">
	<table id="form">
		<tr id="form">
			<td id="form" width="150"><?php echo first_name ?>:</td>
			<td id="form"><input type="text" name="player_first_name"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo last_name ?>:</td>
			<td id="form"><input type="text" name="player_last_name"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo(birth_date.' ('.date_model.')'); ?>:</td>
			<td id="form"><input type="text" name="player_birth_date"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo club ?>:</td>
			<td id="form"><input type="text" name="player_club"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo nationality ?>:</td>
			<td id="form"><input type="text" name="player_nationality"></td>
		</tr>
		<tr id="form"><td id="form"><input type="submit" value="<?php echo submit ?>"></td><td id="form"></td></tr>
	</table>
	</form>
</div>
