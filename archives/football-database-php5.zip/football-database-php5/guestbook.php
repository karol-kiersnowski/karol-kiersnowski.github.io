<div id="content_title">
	<h3><?php echo guestbook; ?></h3> -> 
	<a href="index.php?language=<?php echo $language; ?>&display=guestbook_add"><?php echo add_opinion ?></a>
</div>
<div id="content2">
<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");
	$result=mysql_query('SELECT * FROM guestbook ORDER BY date DESC');
	while( $row=mysql_fetch_array($result) )
	{
		echo( '<div id="text"><p id="inline">Nick: '.$row['nick'].'</p><p id=added>'.added.': '.$row['date'].'</p><hr><p>'.$row['text'].'</p></div>' );
	}
	mysql_close($link);
?>
</div>

