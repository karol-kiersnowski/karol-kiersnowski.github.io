<?php

	define('title','football database');
	define('other_version','wersja polska');
	define('home','Home');
	define('about','About');
	define('guestbook','Guestbook');
	define('database','Database');
	define('calendar','Calendar');
	define('players','Players');
	define('clubs','Clubs');
	define('nationals','National Teams');
	define('stadiums','Stadiums');
	define('today_is','Today is');
	define('birthdays','Birthdays:');
	define('administration_panel','Administration panel');
	define('login','Login');
	define('password','Password');
	// about
	define('about_text','Football Database is a service where users can common create database - add, modify football players, clubs, national teams and stadiums.');
	// adding news
	define('added','Added');
	define('subject_in_english','Subject in English');
	define('subject_in_polish','Subject in Polish');
	define('subject_db','subject_in_english');
	define('contents','Contents');
	define('contents_in_english','Contents in English');
	define('contents_in_polish','Contents in Polish');
	define('contents_db','contents_in_english');
	// adding to the database
	define('add_news','Add an information (only for admin)');
	define('add_opinion','Add your opinion to the guestbook');
	define('add_club','Add a club to the database');
	define('add_national','Add a national team to the database');
	define('add_player','Add a player to the datebase');
	define('add_stadium','Add a stadium to the database');
	define('submit','Submit');
	define('error_nick','Incorrect nick');
	define('error_text','Incorrect text');
	define('error_password','Incorrect password');
	define('no_errors','Your opinion is saved');
	define('correct_password','You are logged');
	// database
	define('first_name','First name');
	define('last_name','Last name');
	define('birth_date','Birth date');
	define('date_model','YYYY-MM-DD');
	define('club','Club');
	define('nationality','Nationality');

	define('name','Name');
	define('name_in_english','Name in English');
	define('name_in_polish','Name in Polish');
	define('stadium','Stadium');
	define('national_stadium','National stadium');
	define('capacity','Capacity');
	define('country','Country');
	define('league','League');
	define('coach','Coach');
	define('national_db','national_en');
?>
