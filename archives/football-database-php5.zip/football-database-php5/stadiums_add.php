<div id="content_title"><h3><?php echo stadiums; ?></h3></div>
<div id="content2">
<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");

	if (isset($_POST['stadium_name']))
	{
        mysql_query( "INSERT INTO stadiums (full_name, capacity, club, country) VALUES(\"$_POST[stadium_name]\",\"$_POST[stadium_capacity]\",\"$_POST[stadium_club]\",\"$_POST[stadium_country]\") ") or die( mysql_error() );
	}
	mysql_close($link);
?>
	<h2><?php echo add_stadium ?></h2>
	<form name="form" action="index.php?language=<?php echo $language; ?>&display=stadiums_add" method="POST">
	<table id="form">
		<tr id="form">
			<td id="form" width="150"><?php echo name ?>:</td>
			<td id="form"><input type="text" name="stadium_name"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo capacity ?>:</td>
			<td id="form"><input type="text" name="stadium_capacity"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo club ?>:</td>
			<td id="form"><input type="text" name="stadium_club"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo country ?>:</td>
			<td id="form"><input type="text" name="stadium_country"></td>
		</tr>
		<tr id="form"><td id="form"><input type="submit" value="<?php echo submit ?>"></td><td id="form"></td></tr>
	</table>
	</form>
</div>
