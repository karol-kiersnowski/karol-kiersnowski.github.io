<div id="content_title">
	<h3><?php echo nationals; ?></h3> -> 
	<a href="index.php?language=<?php echo $language; ?>&display=nationals_add"><?php echo add_national ?></a>
</div>
<div id="content2">
<table>
	<tr>
		<th><?php echo name ?></th>
		<th><?php echo league ?></th>
		<th><?php echo national_stadium ?></th>
		<th><?php echo coach ?></th>
	</tr>
	<?php
		$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 		mysql_select_db("footballdatabase_cba_pl");
		$result=mysql_query('SELECT * FROM nationals');
		while( $row=mysql_fetch_array($result) )
		{
			echo( '<tr><td>'.$row[national_db].'</td><td>'.$row['league'].'</td><td>'.$row['national_stadium'].'</td><td>'.$row['coach'].'</td></tr>' );
		}
		mysql_close($link);
	?>
</table>
</div>
