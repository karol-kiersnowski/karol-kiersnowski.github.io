<div id="content_title">
	<h3><?php echo clubs; ?></h3> -> 
	<a href="index.php?language=<?php echo $language; ?>&display=clubs_add"><?php echo add_club ?></a>
</div>
<div id="content2">
<table>
	<tr>
		<th><?php echo name ?></th>
		<th><?php echo stadium ?></th>
		<th><?php echo league ?></th>
		<th><?php echo coach ?></th>
	</tr>
	<?php
		$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 		mysql_select_db("footballdatabase_cba_pl");
		$result=mysql_query('SELECT * FROM clubs');
		while( $row=mysql_fetch_array($result) )
		{
			echo( '<tr><td>'.$row['full_name'].'</td><td>'.$row['stadium'].'</td><td>'.$row['league'].'</td><td>'.$row['coach'].'</td></tr>' );
		}
		mysql_close($link);
	?>
</table>
</div>
