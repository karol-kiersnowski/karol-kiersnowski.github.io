<?php
	header('Content-Type: text/html; charset=utf-8');
	define('title', 'piłkarska baza danych');
	define('other_version','english version');
	define('home', 'Strona glówna');
	define('about', 'O stronie');
	define('guestbook', 'Księga gości');
	define('database', 'Baza danych');
	define('calendar', 'Kalendarz');
	define('players','Piłkarze');
	define('clubs','Kluby');
	define('nationals','Reprezentacje');
	define('stadiums','Stadiony');
	define('today_is','Dziś jest');
	define('birthdays','Urodziny:');
	define('administration_panel','Panel administracyjny');
	define('login','Logowanie');
	define('password','Hasło');
	// about
	define('about_text','Piłkarska baza danych jest serwisem, gdzie użytkownicy mogą wspólnie tworzyć bazę danych - dodawać, modyfikować piłkarzy, kluby, reprezentacje i stadiony.');
	// adding news
	define('added','Dodane');
	define('subject_in_english','Temat po angielsku');
	define('subject_in_polish','Temat po polsku');
	define('subject_db','subject_in_polish');
	define('contents','Treść');
	define('contents_in_english','Treść po angielsku');
	define('contents_in_polish','Treść po polsku');
	define('contents_db','contents_in_polish');
	// adding to the database
	define('add_news','Dodaj nową wiadomość (tylko administrator)');
	define('add_opinion','Dodaj wpis do księgi gości');
	define('add_club','Dodaj klub do bazy danych');
	define('add_national','Dodaj reprezentację do bazy danych');
	define('add_player','Dodaj piłkarza do bazy danych');
	define('add_stadium','Dodaj stadion do bazy danych');
	define('submit','Wyślij');
	define('error_nick','Wpisano niepoprawny nick');
	define('error_text','Wpisano niepoprawny tekst');
	define('error_password','Wpisano niepoprawne hasło');
	define('no_errors','Twoja opinia została zapisana');
	define('correct_password','Jesteś zalogowany');
	// database
	define('first_name','Imię');
	define('last_name','Nazwisko');
	define('birth_date','Data urodzenia');
	define('date_model','RRRR-MM-DD');
	define('club','Klub');
	define('nationality','Narodowość');

	define('name','Nazwa');
	define('name_in_english','Nazwa po angielsku');
	define('name_in_polish','Nazwa po polsku');
	define('stadium','Stadion');
	define('national_stadium','Stadion narodowy');
	define('capacity','Pojemność');
	define('country','Kraj');
	define('league','Liga');
	define('coach','Trener');
	define('national_db','national_pl');
?>
