<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/strict.dtd">
<?php include('sys.php'); ?>
<html>
<head>
	<link rel="stylesheet" href="styles.css" type="text/css">
	<meta http-equiv="content-type" content="text/html; charset="UTF-8">
	<meta http-equiv="pragma" content="no-cache">
	<meta name="description" content="players, clubs, national teams, stadiums, piłkarze, kluby, reprezentacje, stadiony">
	<meta name="keywords" content="Football Database, Piłkarska Baza Danych">
	<title>football database - <?php echo $display; ?></title>
</head>
<body>
<div id="site">
	<div id="header">
		<h1><?php echo title ?></h1>
		<?php if ($language == 'english') { ?>
		<a id="version" href="index.php?language=polish&display=<?php echo $display; ?>">wersja polska</a>
		<?php } else { ?>
		<a id="version" href="index.php?language=english&display=<?php echo $display; ?>">English version</a>
		<?php } ?>
	</div>
	<div id="menu">
		<div id="menu_title"><h3>Menu</h3></div>
		<div id="menu_content">
			<ul>
				<li><a href="index.php?language=<?php echo $language; ?>"><?php echo home ?></a></li>
				<li><a href="index.php?language=<?php echo $language; ?>&display=about"><?php echo about ?></a></li>
				<li><a href="index.php?language=<?php echo $language; ?>&display=guestbook"><?php echo guestbook ?></a></li>
			</ul>
		</div>
		<div id="menu_title"><h3><?php echo database ?></h3></div>
		<div id="menu_content">
			<ul>
				<li><a href="index.php?language=<?php echo $language; ?>&display=clubs"><?php echo clubs ?></a></li>
				<li><a href="index.php?language=<?php echo $language; ?>&display=nationals"><?php echo nationals ?></a></li>
				<li><a href="index.php?language=<?php echo $language; ?>&display=players"><?php echo players ?></a></li>
				<li><a href="index.php?language=<?php echo $language; ?>&display=stadiums"><?php echo stadiums ?></a></li>
			</ul>
		</div>
		<div id="menu_title"><h3><?php echo calendar ?></h3></div>
		<div id="menu_content"><?php include("calendar.php"); ?></div>
	</div>
	<div id="content">
		<?php if( file_exists($display.'.php') ) include($display.'.php'); else echo('Error 404'); ?>
	</div>
	<div id="footer">
		<h5>Copyright 2014</h5> | 
		<h5><a href="index.php?language=<?php echo $language; ?>&display=login"><?php echo administration_panel ?></a></h5>
	</div>
</div>
</body>
</html>
