<div id="content_title"><h3><?php echo nationals; ?></h3></div>
<div id="content2">
<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");

	if (isset($_POST['national_name_en']))
	{
        mysql_query( "INSERT INTO nationals (national_en, national_pl, league, national_stadium, coach) VALUES(\"$_POST[national_name_en]\",\"$_POST[national_name_pl]\",\"$_POST[national_league]\", \"$_POST[national_stadium_add]\", \"$_POST[national_coach]\") ") or die( mysql_error() );
	}
	mysql_close($link);
?>
	<h2><?php echo add_national ?></h2>
	<form name="form" action="index.php?language=<?php echo $language; ?>&display=nationals_add" method="POST">
	<table id="form">
		<tr id="form">
			<td id="form" width="150"><?php echo name_in_english ?>:</td>
			<td id="form"><input type="text" name="national_name_en"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo name_in_polish ?>:</td>
			<td id="form"><input type="text" name="national_name_pl"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo league ?>:</td>
			<td id="form"><input type="text" name="national_league"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo national_stadium ?>:</td>
			<td id="form"><input type="text" name="national_stadium_add"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo coach ?>:</td>
			<td id="form"><input type="text" name="national_coach"></td>
		</tr>
		<tr id="form"><td id="form"><input type="submit" value="<?php echo submit ?>"></td><td id="form"></td></tr>
	</table>
	</form>
</div>
