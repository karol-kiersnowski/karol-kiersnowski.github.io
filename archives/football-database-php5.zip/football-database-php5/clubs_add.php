<div id="content_title"><h3><?php echo clubs; ?></h3></div>
<div id="content2">
<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");

	if (isset($_POST['club_name']))
	{
        mysql_query( "INSERT INTO clubs (full_name, stadium, league, coach) VALUES(\"$_POST[club_name]\", \"$_POST[club_stadium]\",\"$_POST[club_league]\", \"$_POST[club_coach]\") ") or die( mysql_error() );
	}
	mysql_close($link);
?>
	<h2><?php echo add_club ?></h2>
	<form name="form" action="index.php?language=<?php echo $language; ?>&display=clubs_add" method="POST">
	<table id="form">
		<tr id="form">
			<td id="form" width="150"><?php echo name ?>:</td>
			<td id="form"><input type="text" name="club_name"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo stadium ?>:</td>
			<td id="form"><input type="text" name="club_stadium"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo league ?>:</td>
			<td id="form"><input type="text" name="club_league"></td>
		</tr>
		<tr id="form">
			<td id="form" width="150"><?php echo coach ?>:</td>
			<td id="form"><input type="text" name="club_coach"></td>
		</tr>
		<tr id="form"><td id="form"><input type="submit" value="<?php echo submit ?>"></td><td id="form"></td></tr>
	</table>
	</form>
</div>
