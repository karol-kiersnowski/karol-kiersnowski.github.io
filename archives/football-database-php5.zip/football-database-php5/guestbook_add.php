<div id="content_title"><h3><?php echo guestbook; ?></h3></div>
<div id="content2">
<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");

	if (isset($_POST['nick']))
	{
    	$error='';
		if (strlen($_POST['nick'])<3 || strlen($_POST['nick'])>15) $error=error_nick; 
    	if (strlen($_POST['text'])<10 || strlen($_POST['text'])>1024) $error=error_text;
		if ($error!='')
		{
			echo ($error.'<br>');
		}
		else
		{
			$error=no_errors;
			echo ($error.'<br>');
        	mysql_query( "INSERT INTO guestbook (nick, text) VALUES(\"$_POST[nick]\",\"$_POST[text]\") ") or die( mysql_error() );
	 	}
	}
	mysql_close($link);
?>
	<h2><?php echo add_opinion ?></h2>
	<form name="form" action="index.php?language=<?php echo $language; ?>&display=guestbook_add" method="POST">
	<table id="form">
		<tr id="form">
			<td id="form" width="75">Nick:</td>
			<td id="form"><input type="text" name="nick"></td>
		</tr>
		<tr id="form">
			<td id="form"><?php echo contents ?>:</td>
			<td id="form"><textarea cols="31" rows="3" name="text"></textarea></td>
		</tr>
		<tr id="form">
			<td id="form"><input type="submit" value="<?php echo submit ?>"></td>
			<td id="form"></td>
		</tr>
	</table>
	</form>
</div>
