<div id="content_title"><h3><?php echo about; ?></h3></div>
<div id="content2">
	<p><?php echo about_text ?></p>
</div>
