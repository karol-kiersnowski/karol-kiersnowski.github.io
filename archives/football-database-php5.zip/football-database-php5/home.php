<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");
?>
<div id="content_title"><h3><?php echo home; ?></h3></div>
<div id="content2">
<?php
	$result=mysql_query('SELECT * FROM news ORDER BY date DESC');
	while( $row=mysql_fetch_array($result) )
	{
		echo( '<div id="text"><h2>'.$row[subject_db].'</h2><p id=added>'.added.': '.$row['date'].'</p><hr><p>'.$row[contents_db].'</p></div>' );
	}
	mysql_close($link);
?>
</div>
