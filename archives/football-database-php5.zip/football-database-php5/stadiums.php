<div id="content_title">
	<h3><?php echo stadiums; ?></h3> -> 
	<a href="index.php?language=<?php echo $language; ?>&display=stadiums_add"><?php echo add_stadium ?></a>
</div>
<div id="content2">
<table>
	<tr>
		<th><?php echo name ?></th>
		<th><?php echo capacity ?></th>
		<th><?php echo club ?></th>
		<th><?php echo country ?></th>
	</tr>
	<?php
		$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 		mysql_select_db("footballdatabase_cba_pl");
		$result=mysql_query('SELECT * FROM stadiums');
		while( $row=mysql_fetch_array($result) )
		{
			echo( '<tr><td>'.$row['full_name'].'</td><td>'.$row['capacity'].'</td><td>'.$row['club'].'</td><td>'.$row['country'].'</td></tr>' );
		}
		mysql_close($link);
	?>
</table>
</div>
