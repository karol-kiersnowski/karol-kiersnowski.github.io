<div id="content_title"><h3><?php echo administration_panel; ?></h3></div>
<div id="content2">
<?php
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
 	mysql_select_db("footballdatabase_cba_pl");

	if (isset($_POST['subject_english']))
	{
        mysql_query( "INSERT INTO news (subject_in_english, subject_in_polish, contents_in_english, contents_in_polish) VALUES(\"$_POST[subject_english]\",\"$_POST[subject_polish]\",\"$_POST[contents_english]\",\"$_POST[contents_polish]\") ") or die( mysql_error() );
	}
	mysql_close($link);
?>
	<h2><?php echo add_news ?></h2>
	<form name="form" action="index.php?language=<?php echo $language; ?>&display=home_add_news" method="POST">
	<div id="text">
	<table id="form">
		<tr id="form">
			<td id="form" width="150"><?php echo subject_in_english ?>:</td>
			<td id="form"><input type="text" name="subject_english"></td>
		</tr>
		<tr id="form">
			<td id="form"><?php echo subject_in_polish ?>:</td>
			<td id="form"><input type="text" name="subject_polish"></td>
		</tr>
		<tr id="form">
			<td id="form"><?php echo contents_in_english ?>:</td><td id="form">
			<textarea cols="31" rows="3" name="contents_english"></textarea></td>
		</tr>
		<tr id="form">
			<td id="form"><?php echo contents_in_polish ?>:</td>
			<td id="form"><textarea cols="31" rows="3" name="contents_polish"></textarea></td>
		</tr>
		<tr id="form"><td id="form"><input type="submit" value="<?php echo submit ?>"></td><td id="form"></td></tr>
	</table>
	</div>
	</form>
</div>
<script type="text/javascript">window.alert("Jeste� zalogowany");</script>