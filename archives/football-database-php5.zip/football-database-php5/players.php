<div id="content_title">
	<h3><?php echo players; ?></h3> -> 
	<a href="index.php?language=<?php echo $language; ?>&display=players_add"><?php echo add_player ?></a>
</div>
<div id="content2">
<table>
	<tr>
		<th><?php echo first_name ?></th>
		<th><?php echo last_name ?></th>
		<th><?php echo birth_date ?></th>
		<th><?php echo club ?></th>
		<th><?php echo nationality ?></th>
	</tr>
	<?php
		$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
		mysql_select_db("footballdatabase_cba_pl");
		$result=mysql_query('SELECT * FROM players');
		while( $row=mysql_fetch_array($result) )
		{
			echo( '<tr><td>'.$row['first_name'].'</td><td>'.$row['last_name'].'</td><td>'.$row['birth_date'].'</td><td>'.$row['club'].'</td><td>'.$row['nationality'].'</td></tr>' );
		}
		mysql_close($link);
	?>
</table>
</div>
