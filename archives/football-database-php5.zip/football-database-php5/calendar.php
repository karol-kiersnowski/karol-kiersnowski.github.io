<?php
	echo( today_is.'<br><b>'.date( "d.m.Y" ).' r.</b><br>' );
	echo( '<br>'.birthdays.'<br>' );

	/*
	$link = mysql_connect("mysql.cba.pl","footballdatabase","cba6596596") or die ("Can't connect");
	mysql_select_db("footballdatabase_cba_pl");
	$result=mysql_query('SELECT * FROM players WHERE birth_date=');
	while( $row=mysql_fetch_array($result) )
	{
		echo( $row['first_name'].' '.$row['last_name'] );
	}
	mysql_close($link);*/
?>
