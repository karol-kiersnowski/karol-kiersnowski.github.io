<?php
	if( isset($_POST['pass']) && $_POST['pass'] == 'ynwa' ) include('home_add_news.php');
	else {
?>
<div id="content_title"><h3><?php echo administration_panel ?></h3></div>
<div id="content2">
	<?php
		$error='';
		if( isset($_POST['pass']) ) $error=error_password;
		if ($error!='') echo ($error.'<br>');
	?>
	<h2><?php echo login ?></h2>
	<form name="login_form" action="index.php?language=<?php echo $language; ?>&display=login" method="POST">
	<table id="form">
		<tr id="form">
			<td id="form" width="75"><?php echo password ?>:</td>
			<td id="form" width="100"><input type="password" name="pass" value="" size="7"></td>
			<td id="form"><input type="submit" value="<?php echo submit ?>"></td>
		</tr>
	</table>
	</form>
</div>
<?php } ?>
