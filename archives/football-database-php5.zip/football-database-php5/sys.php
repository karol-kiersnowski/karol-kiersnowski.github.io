<?php
	$languages=array('english', 'polish');
	if( isset($_GET['language']) ) $language=$_GET['language']; else $language='';
	if( !in_array($language,$languages) ) $language=$languages[0];
	if( file_exists($language.'.php') ) include($language.'.php');

	$sites=array('home','about','guestbook','clubs','nationals','players','stadiums','login', 'home_add_news','guestbook_add','clubs_add','nationals_add','players_add','stadiums_add');
	if( isset($_GET['display']) ) $display=$_GET['display']; else $display='';
	if( !in_array($display,$sites) ) $display=$sites[0];
?>
