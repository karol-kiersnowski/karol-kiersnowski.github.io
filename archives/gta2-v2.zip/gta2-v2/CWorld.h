#ifndef CWorld_H
#define CWorld_H
// file CWorld.h

class CWorld
{
public:
    int w; // width
    int h; // height
    CWorld();
};

#endif
