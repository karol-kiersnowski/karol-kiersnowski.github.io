#include "CWorld.h"

CWorld::CWorld()
{
    w = 640;
    h = 480;
}
