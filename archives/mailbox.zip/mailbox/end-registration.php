<!DOCTYPE html>
<html lang="pl-PL">
<head>
	<meta charset="utf8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<meta http-equiv="refresh" content="2; url=index.php"/>
	<title>GucioMail - utworzono konto</title>
	<link rel="stylesheet" href="style.css"/>
</head>
<body>
	<header>
		<h1>G<small>ucio</small>Mail</h1>
		<h2>Utworzono konto</h2>
	</header>
	<section>
		
	</section>
	<footer>
		<h2 id="footer">Copyleft 2017 by GucioMail Team</h2>
	</footer>
</body>
</html>