<!DOCTYPE html>
<html lang="pl-PL">
<head>
	<meta charset="utf8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" href="style.css"/>
	<title>GucioMail - logowanie</title>
</head>
<body>
	<header>
		<h1>G<small>ucio</small>Mail</h1>
		<h2>Logowanie</h2>
	</header>
	<section>
		<form method="get" action="scripts/sign-in.php">
			<div>
				<input type="text" autofocus required maxlength="25"
					   class="mail" name="username" id="username" placeholder="Nazwa użytkownika" />
				<label for="username">@gmail.pl</label>
			</div>
			<div>
				<input type="password" required maxlength="25"
					   name="password" placeholder="Hasło" />
			</div>
			<?php
				//if ( isset($isCorrectData) )
					//echo "Podałeś niepoprawny login i/lub hasło";
			?>
			<div>
				<input type="submit" value="Zaloguj" />
			</div>
			<div style="text-align: center;">
				<a href="new-account.php">Utwórz nowe konto</a>
			</div>
		</form>
	</section>
	<footer>
		<h2 id="footer">Copyleft 2017 by GucioMail Team</h2>
	</footer>
</body>
</html>