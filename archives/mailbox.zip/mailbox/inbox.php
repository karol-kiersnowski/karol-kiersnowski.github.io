<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pl-PL">
<head>
	<meta charset="utf8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>GucioMail - skrzynka odbiorcza</title>
	<link rel="stylesheet" href="style.css"/>
</head>
<body>
	<header>
		<h1>G<small>ucio</small>Mail</h1>
		<p><small>Zalogowano jako: </small><?php echo $_SESSION["username"]; ?>@gmail.pl</p>
		<h2>Skrzynka odbiorcza</h2>
	</header>
	<nav>
		<ul>
			<li><a href="new-message.php">Nowa wiadomość</a></li>
			<li><a href="outbox.php">Skrzynka nadawcza</a></li>
			<li><a href="scripts/sign-out.php">Wyloguj</a></li>
		</ul>
	</nav>
	<section>
		<table>
			<tr>
				<th>Nadawca</th>
				<th>Temat</th>
				<th>Data</th>
			</tr>
			<?php
				include "scripts/view-received-messages.php";
			?>
		</table>
	</section>
	<footer>
		<h2 id="footer">Copyleft 2017 by GucioMail Team</h2>
	</footer>
</body>
</html>