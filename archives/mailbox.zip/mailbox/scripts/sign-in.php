<?php
	include_once "connect.php";
	
		session_start();
		$username = $_GET["username"];
		$password = $_GET["password"];
		$isCorrectData = false;
	
		$connection = connect();
		
		$sql = "SELECT username, password FROM account";
		$result = $connection->query($sql);
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				//echo "username: " . $row["username"]. "<br>";
				if ($username == $row["username"] &&
					$password == $row["password"])
					$isCorrectData = true;
			}
		}
		
		disconnect($connection);
		
		if ($isCorrectData) {
			$_SESSION["username"] = $username;
			if (isset($_SESSION["username"]))
				header('Location: ../inbox.php');
		}
		else {
			//echo "Podałeś nieprawidłowy login i/lub hasło";
			header('Location: ../index.php');
		}
?>