<?php
	function connect() {
		$host = "localhost";
		$user = "root";
		$password = "";
		$database = "guciomail";

		$connection = new mysqli($host, $user, $password);
		if ($connection->connect_error)
			die("Nie można połączyć się z bazą danych. " . $connection->connect_error);

		$connection->select_db($database);
		
		/*if ($connection->connect_error) {
			$sql = "CREATE DATABASE guciomail1";
			$connection->query($sql);
		}*/

		return $connection;
	}
	
	function disconnect($connection) {
		$connection->close();
	}
?>