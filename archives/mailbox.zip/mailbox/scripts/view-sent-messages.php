<?php
	include_once "connect.php";
	
	$connection = connect();
	
	$sql = "SELECT id, sentBy, sentTo, topic, content FROM message WHERE sentBy='" . $_SESSION['username'] . "'";
	$result = $connection->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "<tr>";
			echo "<td>" . $row["sentTo"] . "@gmail.pl</td>";
			echo "<td>" . $row["topic"] . "</td>";
			echo "</tr>";
		}
	}
	
	disconnect($connection);
?>