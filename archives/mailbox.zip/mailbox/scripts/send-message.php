<?php
	session_start();
	include_once "connect.php";
	
	echo $_SESSION['username'];
	$sentBy = $_SESSION['username'];
	$sentTo = $_GET["sentTo"];
	$topic = $_GET["topic"];
	$content = $_GET["content"];
	
	$connection = connect();
	
	$sql = "INSERT INTO message VALUES(default,'" . $sentBy . "','" . $sentTo . "','" . $topic . "','" . $content . "')";
	
	if ($connection->query($sql) === TRUE)
		header('Location: ../successful-sending.php');
	else
		echo "Błąd: " . $sql . "<br>" . $connection->error;
	
	disconnect($connection);
?>