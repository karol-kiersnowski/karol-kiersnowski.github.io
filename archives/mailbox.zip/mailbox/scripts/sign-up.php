<?php
	session_start();
	session_unset(); 
	include_once "connect.php";
	
	$username = $_GET["username"];
	$password = $_GET["password"];
	$confirmedPassword = $_GET["confirmedPassword"];
	
	if ($password != $confirmedPassword)
		echo "Podane hasła różnią się";
	else {
		$connection = connect();
			
		$sql = "INSERT INTO account VALUES ('$username', '$password', null)";
		if ($connection->query($sql) === TRUE) {
			$sql = "INSERT INTO message VALUES(default,'admin','" . $username . "','Witaj " . $username . "',null)";
			$connection->query($sql);
			$_SESSION["username"] = $username;
			header('Location: ../inbox.php');
		} else {
			echo "Błąd: " . $sql . "<br>" . $connection->error;
		}
		
		disconnect($connection);
	}
?>