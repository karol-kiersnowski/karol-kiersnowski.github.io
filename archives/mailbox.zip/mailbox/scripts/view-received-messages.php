<?php
	include_once "connect.php";
	
	$connection = connect();
	$sql = "SELECT id, sentBy, sentTo, topic, content FROM message WHERE sentTo='" . $_SESSION['username'] . "'";
	$result = $connection->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "<tr>";
			echo "<td>" . $row["sentBy"] . "@gmail.pl</td>";
			echo "<td><a href='message.php'>" . $row["topic"] . "</a></td>";
			echo "</tr>";
		}
	}
	
	disconnect($connection);
?>