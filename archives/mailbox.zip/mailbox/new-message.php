<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pl-PL">
<head>
	<meta charset="utf8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>GucioMail - nowa wiadomość</title>
	<link rel="stylesheet" href="style.css"/>
</head>
<body>
	<header>
		<h1>G<small>ucio</small>Mail</h1>
		<p><small>Zalogowano jako: </small><?php echo $_SESSION["username"]; ?>@gmail.pl</p>
		<h2>Nowa wiadomość</h2>
	</header>
	<nav>
		<ul>
			<li><a href="inbox.php">Skrzynka odbiorcza</a></li>
			<li><a href="outbox.php">Skrzynka nadawcza</a></li>
			<li><a href="scripts/sign-out.php">Wyloguj</a></li>
		</ul>
	</nav>
	<section>
		<form action="scripts/send-message.php">
			<div>
				<input type="text" autofocus required maxlength="25"
					   class="mail" name="sentTo" id="sentTo" placeholder="Adresat" />
				<label for="sentTo">@gmail.pl</label>
			</div>
			<div>
				<input type="text" required maxlength="80"
					   name="topic" placeholder="Temat" />
			</div>
			<div>
				<textarea type="text" required maxlength="160"
					   name="content" placeholder="Treść wiadomości"></textarea>
			</div>
			<div>
				<input type="submit" value="Wyślij" />
			</div>
		</form>
	</section>
	<footer>
		<h2 id="footer">Copyleft 2017 by GucioMail Team</h2>
	</footer>
</body>
</html>